@extends('app')

@section('content')
    <div>Hello from Index Students</div>
@endsection